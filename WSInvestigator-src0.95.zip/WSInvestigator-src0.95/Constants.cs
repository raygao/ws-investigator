using System;
using System.Collections.Generic;
using System.Text;

namespace wssearch
{
    class Constants
    {
        public static string WEBSERVICES = "WEBSERVICES";
        public static string PORTLET = "PORTLET";
        public static string COMMUNITY = "COMMUNITY";
        public static string COMMUNITYPAGE = "COMMUNITYPAGE";
    }
}
